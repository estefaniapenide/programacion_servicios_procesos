package modificacion;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.SocketAddress;

public class Almacen extends Thread{
	public static String msg = "";
	String nom;
	MulticastSocket ms=null;
	byte[] buf = new byte[1000];
	public Almacen(String nom, MulticastSocket ms) {
		this.nom=nom;
		this.ms=ms;
	}
	
	public void run() {
		
		while(true) {
		System.out.println("Esperando");
		try {
		 
		while (!msg.toString().trim().equals("*")) {
			System.out.println("Entrando");
			// Recibe el paquete del servidor multicast
			DatagramPacket paquete = new DatagramPacket(buf, buf.length);
			ms.receive(paquete);
			System.out.println("recibido");
			String texto = new String(paquete.getData(), 0, paquete.getLength());
			System.out.println("Recibo: " + texto.toString().trim());	
		}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//ms.leaveGroup(sock, NetworkInterface.getByInetAddress(grupo)); // abandonamos grupo
		//ms.close(); // cierra socket
		System.out.println("Socket cerrado...");
		}
		
	}

	public static void main(String[] args) throws IOException {
		// FLUJO PARA ENTRADA ESTANDAR
		 BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	    
	    //Se crea el socket multicast. 
	    MulticastSocket ms = new MulticastSocket(); 
	    
	    int Puerto = 12345;//Puerto multicast
	    InetAddress grupo = InetAddress.getByName("225.0.0.1");//Grupo
	    
	 // Nos unimos al grupo		
	 SocketAddress sock = new InetSocketAddress(grupo, Puerto);
	 ms.joinGroup(sock, NetworkInterface.getByInetAddress(grupo));// Nos unimos al grupo

	   Almacen almacen = new Almacen("Almacen",ms);
	   almacen.start();

		
	}

}
