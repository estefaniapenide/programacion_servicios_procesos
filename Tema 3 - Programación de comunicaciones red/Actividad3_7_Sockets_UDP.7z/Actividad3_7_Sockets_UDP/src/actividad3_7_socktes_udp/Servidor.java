package actividad3_7_socktes_udp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;



public class Servidor {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		int Puerto=6000;
		String Host="localhost";
		
		System.out.println("INICIANDO SERVIDOR");
		
		DatagramSocket servidor = new DatagramSocket(Puerto);
		InetAddress IPCliente = InetAddress.getLocalHost();
		
		System.out.println("Esperando al cliente...");
	
		
		int numeroRecibido=0;
	
		//do {
	
			byte[] recibidos = new byte[1024];
			DatagramPacket paqRecibido = new DatagramPacket(recibidos,recibidos.length);
			servidor.receive(paqRecibido);
			ByteArrayInputStream ibs = new ByteArrayInputStream(recibidos);
			ObjectInputStream inObjeto = new ObjectInputStream(ibs);
			Numeros objNumero = (Numeros) inObjeto.readObject();
			inObjeto.close();
			
		
			
			System.out.println("\nN�mero recibido:" +objNumero.getNumero());
		
			numeroRecibido=objNumero.getNumero();
			
			if(numeroRecibido>0 ) {
		
				long cuadradro = objNumero.getNumero()*objNumero.getNumero();
				long cubo = objNumero.getNumero()*objNumero.getNumero()*objNumero.getNumero();
		
				objNumero.setCuadrado(cuadradro);
				objNumero.setCubo(cubo);
				
			
				ByteArrayOutputStream obs = new ByteArrayOutputStream();
				ObjectOutputStream outObjeto = new ObjectOutputStream(obs);
				outObjeto.writeObject(objNumero);
				outObjeto.close();
				
				byte[] enviados = obs.toByteArray();
				DatagramPacket paqEnviado = new DatagramPacket(enviados,enviados.length,IPCliente,Puerto);
				servidor.send(paqEnviado);
				
			
				System.out.println("Respuesta enviada\n");
		
				
		
		}
		//}while(numeroRecibido>0);
	
		servidor.close();
		
		System.out.println("\nSERVIDOR FINALIZADO");

	}

}
