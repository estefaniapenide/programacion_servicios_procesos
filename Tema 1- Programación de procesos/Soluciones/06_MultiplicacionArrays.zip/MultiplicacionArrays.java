import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MultiplicacionArrays {

	public static void main(String[] args) {
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		try {
			String num1, num2;
			do{
				//System.out.println("Introduce 1er numero");
				num1 = br.readLine();				
				//System.out.println("Introduce 2o numero");
				num2 = br.readLine();
				if (num1 != "" && num2 != "")
					System.out.println(Integer.parseInt(num1)*Integer.parseInt(num2));
			}while (num1 != "" && num2 != "");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
