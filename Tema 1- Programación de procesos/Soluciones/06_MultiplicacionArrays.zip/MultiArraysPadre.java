import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class MultiArraysPadre {
	public static void main(String[] args) {
		int[] array1 = { 1, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		int[] array2 = { 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 };
		List<Integer> arrayRes = new ArrayList<Integer>();

		File directorio = new File(".\\bin");
		ProcessBuilder pb = new ProcessBuilder("java", "MultiplicacionArrays");
		pb.directory(directorio);
		try {
			Process esclavo1 = pb.start();
			PrintStream ps1 = new PrintStream(esclavo1.getOutputStream());

			Process esclavo2 = pb.start();
			PrintStream ps2 = new PrintStream(esclavo2.getOutputStream());

			String line1, line2;
			BufferedReader bfr1 = new BufferedReader(new InputStreamReader(esclavo1.getInputStream()));
			BufferedReader bfr2 = new BufferedReader(new InputStreamReader(esclavo2.getInputStream()));

			for (int i = 0; i < 5; i++) {
				System.out.println("ES1: Multiplicando: " + array1[i] + " " + array2[i]);
				ps1.println(array1[i]);
				ps1.println(array2[i]);
				ps1.flush();

				System.out.println("ES2: Multiplicando: " + array1[5 + i] + " " + array2[5 + i]);
				ps2.println(array1[5 + i]);
				ps2.println(array2[5 + i]);
				ps2.flush();
				
				if ((line1 = bfr1.readLine()) != null) {
					arrayRes.add(Integer.parseInt(line1));

					line2 = bfr2.readLine();
					arrayRes.add(Integer.parseInt(line2));
				}
			}

			esclavo1.destroy();
			esclavo2.destroy();

			System.out.println("ARRAY RESULTADO:");
			System.out.print("[ ");
			for (int i = 0; i < 10; i++) {
				System.out.print(arrayRes.get(i).toString()+" ");
			}
			System.out.print("]");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
