import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
/*
 * Crear un programa Java que sea capaz de sumar todos los n�meros comprendidos entre dos valores, incluyendo ambos valores.
 * */
public class zz_Sumador_Padre {
	public static void main(String[] args) {
		final String commands[] = { "java", "zz_Sumador_Hijo", "1", "5" }; // estos son los comandos a ejecutar
		
		Process process;
		try {
			File directorio = new File(".\\bin");
			process = new ProcessBuilder(commands).directory(directorio).start();

			// Se lee la salida
			InputStream is = process.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			String line;
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
			int exitValue = process.waitFor();
			System.out.println("\nC�digo de salida: " + exitValue);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
}
