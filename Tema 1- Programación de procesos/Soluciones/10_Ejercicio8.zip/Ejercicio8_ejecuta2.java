import java.io.*;
import java.util.Scanner;

public class Ejercicio8_ejecuta2 {
	public static void main(String[] args) throws IOException {

		System.out.println("La cadena est� en el fichero Datos.txt");

		File directorio = new File(".\\bin");
		ProcessBuilder pb = new ProcessBuilder("java", "Ejercicio8_parte1");

		// se establece el directorio donde se encuentra el ejecutable
		pb.directory(directorio);
		
		// Salida a consola
		pb.redirectOutput(ProcessBuilder.Redirect.INHERIT);

		// La cadena esta en un fichero
		File fichero = new File("DatosEjer8.txt");
		pb.redirectInput(ProcessBuilder.Redirect.from(fichero));

		// salida de error a fichero
		File fErr = new File("Ferror.txt");
		pb.redirectError(fErr);

		// se ejecuta el proceso
		Process p = pb.start();

		// COMPROBACION DE ERROR - 0 bien - 1 mal
		int exitVal;
		try {
			exitVal = p.waitFor();
			System.out.println("Valor de Salida: " + exitVal);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}// Ejercicio8_ejecuta2
