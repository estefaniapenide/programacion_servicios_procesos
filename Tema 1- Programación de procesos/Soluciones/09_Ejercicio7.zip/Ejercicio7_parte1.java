import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Ejercicio7_parte1 {
	public static void main(String[] args) {
		String texto = "";

		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		try {

			while (!texto.equals("*")) {
				System.out.print("Introduce una cadena (* para terminar): ");
				texto = br.readLine();
				System.out.println("Cadena introducida: " + texto);
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		// otra forma
		/*
		 * Scanner sc = new Scanner(System.in); try { while (!texto.equals("*")) {
		 * System.out.printf("Introduce una cadena (* para terminar): "); texto =
		 * sc.nextLine(); System.out.println("Cadena introducida: "+texto);
		 * 
		 * } sc.close(); } catch (Exception e) { e.printStackTrace(); }
		 */

	}
}
