import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class Mayusculas {
	public static void main(String args[]) {
		String line;
		try{
			File directorio = new File(".\\bin");			
			ProcessBuilder pb = new ProcessBuilder("java", "ConvertirMayusculas");
			pb.directory(directorio);
			Process hijo = pb.start();
			
			BufferedReader br = new BufferedReader(new InputStreamReader(hijo.getInputStream()));
			PrintStream ps = new PrintStream(hijo.getOutputStream());
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			// Para salir del bucle se puede pulsar Ctrl-D
			// Finaliza la entrada
			while ((line = in.readLine()) != "") {
				ps.println(line);
				ps.flush(); // IMP: Comprueba env�o de datos
				if ((line = br.readLine()) != null) {
					System.out.println(line);
				}
			}
			System.out.println("Finalizando");
		} catch (IOException e) {
			System.out.println("Error ocurri� durante la ejecuci�n. Descripci�n del error: " + e.getMessage());
		}
	}
}
