package Ejercicio2;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class Servidor {

	public static void main(String[] args) {
		

		try {

			byte[] bufer = new byte[1024];

			// ASOCIANDO EL DATAGRAMA AL PUERTO CORRESPONDIENTE
			DatagramSocket servidor = new DatagramSocket(12345);
			
			System.out.println("SERVIDOR");
			System.out.println("Esperando cliente..");

			DatagramPacket recibo;
			DatagramPacket envio;

			Ticket ticket = new Ticket();
			

				// ESPERANDO DATAGRAMA
				recibo = new DatagramPacket(bufer, bufer.length);
				servidor.receive(recibo);
				
				System.out.println("\nSolicitud de ticket recibida");
				
				
				// CONVERTIMOS BYTES A OBJETO
				ByteArrayInputStream bais = new ByteArrayInputStream(bufer);
				ObjectInputStream in = new ObjectInputStream(bais);
				ticket = (Ticket) in.readObject();
				in.close();
				
				System.out.println("Se est� calculando el precio de su ticket...");
				
				String tipoEntrada = ticket.getTipoEntrada();
				
				if(tipoEntrada.equals("Normal")) {
					ticket.setImporte(10);
				}else if(tipoEntrada.equals("Ni�os")) {
					ticket.setImporte(3);
				}else if(tipoEntrada.equals("Carnet Joven")) {
					ticket.setImporte(5);
				}else if(tipoEntrada.equals("Pensionista")) {
					ticket.setImporte(4);
				}else {
					ticket.setTipoEntrada("El tipo de entrada solicitado no existe");
				}
				
				System.out.println(ticket);
				
				System.out.println("\nEnviando confirmaci�n de ticket...");
				
				// DEVOLVIENDO EL MENSAJE
				InetAddress IPOrigen = recibo.getAddress();
				int puerto = recibo.getPort();
				
				// CONVERTIMOS OBJETO A BYTES
				ByteArrayOutputStream bs = new ByteArrayOutputStream();
				ObjectOutputStream out = new ObjectOutputStream(bs);
				out.reset();
				out.writeObject(ticket); // escribir objeto
				
				bufer = bs.toByteArray();

				envio = new DatagramPacket(bufer, bufer.length, IPOrigen, puerto);
				servidor.send(envio);
				
				System.out.println("Confirmaci�n de ticket enviada");
				
				
				servidor.close();
				System.out.println("\nSERVIDOR DESCONECTADO");



		} catch (SocketException e) {
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
