package Ejercicio2;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Cliente {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		System.out.println("CLIENTE");

		try {
			DatagramSocket cliente = new DatagramSocket();

			int Puerto = 12345;// Puerto servidor
			InetAddress IPServidor = InetAddress.getLocalHost();// host servidor

			byte[] bufer = new byte[1024];

			DatagramPacket envio;
			DatagramPacket recibo;
			String nombre = "";
			String tipoEntrada = "";

			System.out.println("Introduzaca el nombre completo del visitante: ");
			nombre = input.nextLine();

			System.out.println("Escoja el n�mero asignado al tipo de entrada:");
			System.out.println("1.-NORMAL (10�)");
			System.out.println("2.-NI�OS (3�)");
			System.out.println("3.-CARNET JOVEN (5�)");
			System.out.println("4.-PENSIONISTA (4�)");

			byte op = input.nextByte();
			switch (op) {
			case 1:
				tipoEntrada = "Normal";
				break;
			case 2:
				tipoEntrada = "Ni�os";
				break;
			case 3:
				tipoEntrada = "Carnet Joven";
				break;
			case 4:
				tipoEntrada = "Pensionista";
				break;
			default:
				System.out.println("\nNo ha introdcido ninguan de las opciones. Las opciones v�lidas son: 1, 2, 3 � 4");
				break;
			}

			if (tipoEntrada.equals("Normal") || tipoEntrada.equals("Ni�os") || tipoEntrada.equals("Carnet Joven")
					|| tipoEntrada.equals("Pensionista")) {

				Ticket ticket = new Ticket();
				ticket.setVisitnate(nombre);
				ticket.setTipoEntrada(tipoEntrada);

				// CONVERTIMOS OBJETO A BYTES
				ByteArrayOutputStream bs = new ByteArrayOutputStream();
				ObjectOutputStream out = new ObjectOutputStream(bs);
				out.reset();
				out.writeObject(ticket); // escribir objeto

				bufer = bs.toByteArray();

				// ENVIANDO DATAGRAMA AL SERVIDOR
				envio = new DatagramPacket(bufer, bufer.length, IPServidor, Puerto);
				cliente.send(envio);

				System.out.println("\nSe est� enviando su solucitud de ticket...");

				// ESPERANDO DATAGRAMA
				recibo = new DatagramPacket(bufer, bufer.length);
				cliente.receive(recibo);

				System.out.println("Ticket confirmado");

				// CONVERTIMOS BYTES A OBJETO
				ByteArrayInputStream bais = new ByteArrayInputStream(bufer);
				ObjectInputStream in = new ObjectInputStream(bais);
				ticket = (Ticket) in.readObject();
				in.close();

				System.out.println("\n"+ticket);
			}
			
			cliente.close();
			System.out.println("\nCLIENTE DESCONECTADO");

		} catch (SocketException e) {
			e.printStackTrace();
		} catch (InputMismatchException e) {
			System.out.println("\nNo ha introdcido ninguan de las opciones. Las opciones v�lidas son: 1, 2, 3 � 4");
			// e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

			
		}

	}

}
