package Ejercicio2;

import java.io.Serializable;

public class Ticket implements Serializable{
	
	private String visitnate;
	private String tipoEntrada;
	private int importe;
	
	public Ticket() {}
	
	public Ticket(String visitnate, String tipoEntrada, int importe) {
		super();
		this.visitnate = visitnate;
		this.tipoEntrada = tipoEntrada;
		this.importe = importe;
	}

	public String getVisitnate() {
		return visitnate;
	}

	public void setVisitnate(String visitnate) {
		this.visitnate = visitnate;
	}


	public String getTipoEntrada() {
		return tipoEntrada;
	}

	public void setTipoEntrada(String tipoEntrada) {
		this.tipoEntrada = tipoEntrada;
	}

	public int getImporte() {
		return importe;
	}

	public void setImporte(int importe) {
		this.importe = importe;
	}
	
	public String toString() {
		String ticket ="VISITANTE: "+visitnate
				+"\nTIPO DE ENTRADA: "+tipoEntrada
				+"\nA PAGAR: "+importe+" �";
		
		return ticket;
	}

}
