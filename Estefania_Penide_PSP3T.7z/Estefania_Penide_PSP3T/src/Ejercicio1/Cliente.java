package Ejercicio1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Cliente {

	public static void main(String[] args) {
		

		String host = "localhost";
		int puerto = 6000;
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("CLIENTE");
		
		try {
			
			Socket cliente = new Socket(host, puerto);

			// FLUJO DE ENTRADA
			InputStream entrada = null;
			entrada = cliente.getInputStream();
			DataInputStream fentrada = new DataInputStream(entrada);

			// FLUJO DE SALIDA
			OutputStream salida = null;
			salida = cliente.getOutputStream();
			DataOutputStream fsalida = new DataOutputStream(salida);
			
			String operador="";
			double num1=0;
			double num2=0;
			
			System.out.println("Escoja el n�mero de la operaci�n a realizar:");
			System.out.println("1.-SUMA");
			System.out.println("2.-RESTA");
			System.out.println("3.-MULTIPLICACI�N");
			System.out.println("4.-DIVIS�N");
			byte op = input.nextByte();
			switch(op) {
			case 1:
				operador="+";
				break;
			case 2:
				operador="-";
				break;
			case 3:
				operador="*";
				break;
			case 4:
				operador="/";
				break;
			default:
				System.out.println("No ha introducido ninguna de las opciones.Las opciones v�lidas son: 1, 2, 3 � 4");
				break;
				
			}
			
			if (operador.equals("+") || operador.equals("-") || operador.equals("*") || operador.equals("/")){
				
				System.out.println("Introduce un n�mero:");
				num1=input.nextDouble();
				System.out.println("Introduce otro n�mero:");
				num2=input.nextDouble();
				
				//ENVIANDO LOS DATOS AL SERVIDOR
				fsalida.writeDouble(num1);
				fsalida.writeUTF(operador);
				fsalida.writeDouble(num2);
				
				//RECIBIENDO LOS DATOS DEL SERVIDOR
				double solucion = fentrada.readDouble();
				
				System.out.println("\nSOLUCI�N:");
				System.out.println(num1+operador+num2+"="+solucion);
			}
			
			//CERRANDO FLUJOS Y SOCKET
			entrada.close();
			fentrada.close();
			salida.close();
			fsalida.close();
			cliente.close();
			
			System.out.println("\nCLIENTE DESCONECTADO");

		}  catch (ConnectException e) {
			System.out.println("\nNO ES POSIBLE CONECTARSE CON EL SERVIDOR");
		}catch (InputMismatchException e) {
			System.out.println("\nNo ha introdcido ninguan de las opciones. Las opciones v�lidas son: 1, 2, 3 � 4");
			// e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void numeros(Scanner input) {
		System.out.println();
	}

}
