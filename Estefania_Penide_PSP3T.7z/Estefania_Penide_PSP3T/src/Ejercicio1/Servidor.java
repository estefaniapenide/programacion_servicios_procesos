package Ejercicio1;

import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

public class Servidor {

	public static void main(String[] args) {

		int puerto = 6000;
		System.out.println("SERVIDOR");

		try {

			System.out.println("Servidor iniciado...\n");

			ServerSocket servidor = new ServerSocket(puerto);

			while (true) {
				Socket cliente = servidor.accept();
				HiloServidor hilo = new HiloServidor(cliente);
				hilo.start();
			}

		} catch (BindException e) {
			System.out.println("ERROR: EL SERVIDOR YA EST� EN USO");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
