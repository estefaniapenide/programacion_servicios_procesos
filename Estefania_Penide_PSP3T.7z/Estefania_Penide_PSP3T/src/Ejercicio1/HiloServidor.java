package Ejercicio1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;

public class HiloServidor extends Thread {

	Socket socket = null;

	InputStream entrada = null;
	DataInputStream fentrada = null;

	OutputStream salida = null;
	DataOutputStream fsalida = null;

	public HiloServidor(Socket socket) {
		this.socket = socket;
		try {

			entrada = socket.getInputStream();
			fentrada = new DataInputStream(entrada);

			salida = socket.getOutputStream();
			fsalida = new DataOutputStream(salida);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {

		String cadena = "";
		System.out.println("=> CONECTA IP" + socket.getLocalAddress() + ", PUERTO REMOTO: " + socket.getPort() + "\n");

		try {

			System.out.print("C�LCULO CLIENTE " + socket.getInetAddress() + "/" + socket.getPort() + " => ");
			double num1 = fentrada.readDouble();
			System.out.print(num1);
			String operador = fentrada.readUTF();
			System.out.print(operador);
			double num2 = fentrada.readDouble();
			System.out.print(num2);

			double solucion = 0;

			switch (operador) {
			case "+":
				solucion = num1 + num2;
				break;
			case "-":
				solucion = num1 - num2;
				break;
			case "*":
				solucion = num1 * num2;
				break;
			case "/":
				solucion = num1 / num2;
				break;
			}

			System.out.print("=" + solucion);

			fsalida.writeDouble(solucion);

			System.out.println(" => CLIENTE DESCONECTADO\n");

			fsalida.close();
			fentrada.close();
			socket.close();
		} catch (SocketException e) {
			System.out.println(" => SE HA INTERRUMPIDO LA CONEXI�N CON EL CLIENTE\n");
		} catch (EOFException e) {
			System.out.println(" => SE HA INTERRUMPIDO LA CONEXI�N CON EL CLIENTE\n");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
